using UnityEngine;

public class Player : MonoBehaviour
{
    public int health;  // The player's health
    public int maxHealth;  // The player's maximum health
    public HealthBar healthBar;  // Reference to the player's health bar
    public Inventory inventory;  // Reference to the player's inventory (new)
    
    private int burnTurnsRemaining = 0;  // Tracks remaining burn turns
    private int burnDamagePerTurn = 0;  // Tracks how much damage is dealt per turn

    private void Start()
    {
        // Initialize health bar
        healthBar.SetHealth(health, maxHealth);

        // Ensure the player starts with an inventory
        if (inventory == null)
        {
            inventory = GetComponent<Inventory>();  // Grab inventory if not set manually
        }
    }

    // Method to heal the player
    public void Heal(int amount)
    {
        health = Mathf.Min(health + amount, maxHealth);
        Debug.Log($"Player healed for {amount}. Current Health: {health}");
        healthBar.SetHealth(health, maxHealth);
    }

    // Method to apply damage to the player
    public void TakeDamage(int amount)
    {
        health -= amount;
        Debug.Log($"Player took {amount} damage. Current Health: {health}");
        healthBar.SetHealth(health, maxHealth);
    }

    // Apply burn damage at the start of the player's turn
    public void ApplyBurnDamage()
    {
        if (burnTurnsRemaining > 0)
        {
            TakeDamage(burnDamagePerTurn);
            burnTurnsRemaining--;
            Debug.Log($"Player took {burnDamagePerTurn} burn damage. {burnTurnsRemaining} turns remaining.");
        }
    }

    // Call this method to set burn details
    public void SetBurnEffect(int damagePerTurn, int turns)
    {
        burnDamagePerTurn = damagePerTurn;
        burnTurnsRemaining = turns;
    }

    // New: Add an ingredient to the pot from the player's inventory
    public bool AddIngredientToPot(Ingredient ingredient, CookingPot cookingPot)
    {
        // Check if the player has the ingredient in their inventory
        if (!inventory.HasIngredient(ingredient))
        {
            Debug.Log("Ingredient not available in inventory.");
            return false;  // Ingredient is not in the inventory, do nothing
        }

        // Remove the ingredient from inventory before adding to the cooking pot
        inventory.RemoveIngredient(ingredient);

        // Add the ingredient to the cooking pot
        cookingPot.AddIngredient(ingredient);  // No return value needed

        return true;  // Ingredient was successfully added
    }
}
