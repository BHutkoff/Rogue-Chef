using System.Collections;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public EnemyData enemyData;  // Reference to the EnemyData ScriptableObject
    public HealthBar healthBar;  // Reference to the enemy's health bar

    private int health;
    private int maxHealth;
    private int totalBurnDamage;  // This will accumulate burn damage applied by ingredients
    private float burnDurationLeft; // Track remaining burn duration

    private float attackCooldownTimer;

    private void Start()
    {
        // Initialize the enemy stats from EnemyData
        if (enemyData != null)
        {
            maxHealth = enemyData.maxHealth;
            health = maxHealth;  // Start with full health
            healthBar.SetHealth(health, maxHealth);

            // Initialize burn damage and duration
            totalBurnDamage = enemyData.burnDamage;
            burnDurationLeft = enemyData.burnDuration;
        }
        else
        {
            Debug.LogError("EnemyData is not assigned!");
        }
    }

    // Method to apply damage to the enemy
    public void TakeDamage(int amount)
    {
        health -= amount;
        Debug.Log($"Enemy took {amount} damage. Current Health: {health}");

        healthBar.SetHealth(health, maxHealth);  // Update the health bar after taking damage
    }

    // Method to add burn damage, which stacks on the enemy
    public void AddBurnDamage(int burnDamage, float burnDuration)
    {
        // Stack burn damage and keep the longest duration
        totalBurnDamage += burnDamage;  // Stack burn damage
        burnDurationLeft = Mathf.Max(burnDurationLeft, burnDuration);  // Keep the longest duration
    }

    // Applies burn damage at the start of the enemy's turn
    public void ApplyBurnDamage()
    {
        if (burnDurationLeft > 0)
        {
            // Apply accumulated burn damage
            TakeDamage(totalBurnDamage);
            burnDurationLeft -= 1f;  // Decrease burn duration each time it's applied
        }
    }

    // New function to handle the enemy's turn actions (e.g., attack)
    public void PerformTurnAction(Player player)
    {
        if (attackCooldownTimer > 0f)
        {
            attackCooldownTimer -= Time.deltaTime;  // Countdown cooldown
            return;  // If the attack is still on cooldown, don't attack
        }

        // Example: Randomly select an attack from the enemy's available attacks
        if (enemyData.attacks.Length > 0)
        {
            int attackIndex = Random.Range(0, enemyData.attacks.Length);  // Select a random attack
            Attack selectedAttack = enemyData.attacks[attackIndex];

            // Perform the attack
            Debug.Log($"Enemy performs {selectedAttack.attackName} attack!");
            player.TakeDamage(selectedAttack.damage);  // Apply damage to player

            // Reset cooldown for that attack
            attackCooldownTimer = selectedAttack.cooldown;

            // End the turn after the attack
            EndTurn();
        }
        else
        {
            Debug.LogWarning("No attacks available for this enemy.");
        }
    }

    // Function to end the enemy's turn
    private void EndTurn()
    {
        // Logic for ending the enemy's turn (could include additional actions)
        Debug.Log("Enemy's turn has ended.");
    }
}
